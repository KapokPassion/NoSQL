package com.bjtu.redis;

import ch.qos.logback.core.util.FileUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class AJ {

    Change ch;

    private ArrayList<String> read;
    private ArrayList<String> write;

    private void init() throws IOException {

            String actionName = ch.cg;

            ClassLoader loader= FileUtil.class.getClassLoader();
            InputStream stream=loader.getResourceAsStream("actions.json");

            String text = IOUtils.toString(stream,"utf8");
            JSONObject jsonObject = JSONObject.parseObject(text);
            JSONArray array = jsonObject.getJSONArray("actions");

            for (int i = 0; i < array.size(); i++){

                JSONObject jo = array.getJSONObject(i);
                String an = jo.getString("cg");
                if(an.equals(actionName)){

                    JSONObject jo1 = jo.getJSONObject("feature_retrieve");
                    JSONObject jo2 = jo.getJSONObject("save_counter");
                    JSONArray Ja1= jo1.getJSONArray("counter");
                    JSONArray Ja2= jo2.getJSONArray("counter");

                    for(int j=0;j<Ja1.size();j++){
                        JSONObject jn = Ja1.getJSONObject(j);
                        read.add(jn.getString("name"));
                    }

                    for(int j=0;j<Ja2.size();j++){
                        JSONObject jn = Ja2.getJSONObject(j);
                        write.add(jn.getString("name"));
                    }
                    break;
                }
            }

    }

    public AJ(Change ch) throws IOException {

        this.ch = ch;

        read = new ArrayList<String>();
        write = new ArrayList<String>();

        init();
    }

    public void setCh(Change ch){
        this.ch = ch;
    }

    public Change getCh() {
        return ch;
    }

    public void setRead(ArrayList<String> read){
        this.read = read;
    }

    public ArrayList<String> getRead() {
        return read;
    }

    public void setWrite(ArrayList<String> write){
        this.write= write;
    }

    public ArrayList<String> getWrite() {
        return write;
    }

}
