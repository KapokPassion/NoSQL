package com.bjtu.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.*;

public class MyJedis {

    public static Jedis jedis = JedisInstance.getInstance().getResource();
    private static JedisPool jedisPool = JedisInstance.getInstance();

    //测一下，之前全失败了。。。。cannot reslove symbol 。。。。玄学
    public static int a(int b){
        return b;
    }

    //为string添加元素
    public static void set(String key, String value) throws Exception {
        jedis.set(key,value);
    }

    //获取string
    public static String get(String key) throws Exception {
        return jedis.get(key);
    }

    //追加string
    public static void append(String key, String value) throws Exception {
        jedis.append(key,value);
    }

    //添加set
    public static void sadd(String key, Set<String> value) throws Exception {
        for(String str: value){
            jedis.sadd(key, str);
        }
    }

    //set删除指定元素
    public static void srem(String key, Set<String> value) throws Exception {
        Iterator<String> it = value.iterator();
        while(it.hasNext()){
            String str = it.next();
            jedis.srem(key, str);
        }
    }

    //获取key对应的value总数
    public static Long scard(String key) throws Exception {
        return jedis.scard(key);
    }

    //获取key对应的所有value
    public static Set<String> smembers(String key) throws Exception {
        return jedis.smembers(key);
    }

    //判断set是否存在
    public static boolean sismember(String key, String value) throws Exception {
        return jedis.sismember(key,value);
    }

    //随机获取数据
    public static String srandmember(String key) throws Exception {
        return jedis.srandmember(key);
    }



    //向list添加元素
    public static void lpush(String key, List<String> list) throws Exception {
        for(String s: list){
            jedis.lpush(key,s);
        }
    }

    //获取list
    public static List<String> lrange(String key, Integer start, Integer end)
            throws Exception {
        return jedis.lrange(key, start, end);
    }

    //删除任意类型的key
    public static void del(String key) throws Exception {
        jedis.del(key);
    }

    //设置map
    public static void hmset(String key, Map<String, String> map) throws Exception {
        jedis.hmset(key,map);
    }

    //获取map的key的个数
    public static Long hlen(String key) throws Exception {
        return jedis.hlen(key);
    }

    //获取map中所有key
    public static Set<String> hkeys(String key) throws Exception {
        return jedis.hkeys(key);
    }

    //获取map中所有value
    public static List<String> hvals(String key) throws Exception {
        return jedis.hvals(key);
    }

    //获取map中的指定key的value
    public List<String> hmget(String key, String... params)
            throws Exception {
        if (null == params || params.length == 0) {
            throw new RuntimeException(this.getClass().getSimpleName()+  "::"
                    + new Exception().getStackTrace()[0].getMethodName()+"参数不能为空");
        }
        return jedis.hmget(key,params);
    }

    //获取map所有的key和value
    public static Map<String, String> hgetAll(String key)
            throws Exception {
        return jedis.hgetAll(key);
    }

    //删除指定key的map
    public void hdel(String key, String... params) throws Exception {
        if (null == params || params.length == 0) {
            throw new RuntimeException(this.getClass().getSimpleName()+  "::"
                    + new Exception().getStackTrace()[0].getMethodName()+"参数不能为空");
        }
        jedis.hdel(key,params);
    }


    public static void setIncr(String key , int field){
        Jedis jedis = null;

        jedis = jedisPool.getResource();
        jedis.incrBy(key,Long.parseLong(String.valueOf(field)));

        jedis.close();

    }

    public static String getValue(String key){
        String str=null;

        jedis = jedisPool.getResource();
        str = jedis.get(key);

        jedis.close();

        return str;
    }

    public static void setHash(String key,String field,String value){

        jedis = jedisPool.getResource();
        jedis.hset(key, field, value);

        jedis.close();

    }

    public static Map<String,String> getHash(String key){
        Map<String,String> str = null;

        jedis = jedisPool.getResource();
        str = jedis.hgetAll(key);

        jedis.close();
        return str;
    }

    public static void setList(String key,String value){

        jedis = jedisPool.getResource();
        jedis.rpush(key,value);

        jedis.close();

    }

    public static List<String> getList(String key){

        List<String> str = null;

        jedis = jedisPool.getResource();
        str = jedis.lrange(key, 0, -1);

        jedis.close();

        return str;
    }

}
