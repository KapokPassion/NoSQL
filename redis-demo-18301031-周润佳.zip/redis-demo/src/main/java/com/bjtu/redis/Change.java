package com.bjtu.redis;

public class Change {

    public String cg;

    public Change(String cg){

        this.cg = cg;
    }
}
