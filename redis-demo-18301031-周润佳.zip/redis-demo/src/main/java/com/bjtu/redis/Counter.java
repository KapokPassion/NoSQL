package com.bjtu.redis;

public class Counter {

    public String name;
    public String type;
    public String key;
    public int num;


    public Counter(String name){
        this.name=name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey(String key) {
        return key;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getNum(int num) {
        return num;
    }



    @Override
    public String toString() {
        return "Counter{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", key='" + key + '\'' +
                ", value=" + num +
                '}';
    }
}