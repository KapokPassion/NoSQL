package com.bjtu.redis;

import java.io.IOException;
import java.util.Scanner;

public class Test {

    public static void show() throws IOException {

        boolean temp1 = false;
        boolean temp2 = false;

        while(true) {

            System.out.println("请选择您想要查询的内容:");
            System.out.println(" 1. 增加count \n " +
                    "2. 查看count值 \n " +
                    "3. 读取freq \n " +
                    "4. 读取log \n " +
                    "0. 退出 \n");

            System.out.print(">>");
            Scanner ms = new Scanner(System.in);

            int choice = Integer.valueOf(ms.nextLine()).intValue();

            if(     (choice != 1)&&
                    (choice != 2)&&
                    (choice != 3)&&
                    (choice != 4)&&
                    (choice != 0)){
                System.out.println("请注意您输入的内容，请输入0~4！");
            }

            else{

                switch (choice){

                    case 1:

                        System.out.println("***** count增加1个 *****");

                        AJ jsh1 = new AJ(new Change("count+1"));
                        Function da1 = new Function(jsh1);
                        da1.Play();

                        break;

                    case 2:

                        System.out.println("***** 读取count数 *****");

                        AJ jsh2 = new AJ(new Change("num"));
                        Function da2 = new Function(jsh2);
                        da2.Play();

                        break;

                    case 3:

                        System.out.println("***** 读取freq *****");

                        AJ jsh3 = new AJ(new Change("freq"));
                        Function da3 = new Function(jsh3);
                        da3.Play();

                        break;

                    case 4:

                        System.out.println("***** 读取log *****");

                        AJ jsh4 = new AJ(new Change("log"));
                        Function da4 = new Function(jsh4);
                        da4.Play();

                        break;

                    case 0:

                        temp1 = true;
                        break;

                    default:

                        break;

                }

            }

            if (temp1){

                temp2 = true;
                break;

            }

            System.out.println("---------该轮查询已结束---------");
        }

        if (temp2){
            System.out.println("----------您已退出----------");
            System.exit(0) ;

        }
    }
}
