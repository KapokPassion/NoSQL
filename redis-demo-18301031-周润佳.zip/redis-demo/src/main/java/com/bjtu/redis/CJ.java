package com.bjtu.redis;

import ch.qos.logback.core.util.FileUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;

public class CJ {

    Counter counter;

    public CJ(Counter counter) throws IOException {

        this.counter=counter;

        init();
    }

    private void init() throws IOException {

        String counterName = counter.name;

        ClassLoader loader = FileUtil.class.getClassLoader();
        InputStream stream = loader.getResourceAsStream("counters.json");


        String text = IOUtils.toString(stream, "utf8");
        JSONObject jsonObject = JSONObject.parseObject(text);
        JSONArray array = jsonObject.getJSONArray("counters");

        for (int i = 0; i < array.size(); i++) {

            JSONObject jo = array.getJSONObject(i);
            String an = jo.getString("name");

            if (an.equals(counterName)) {

                counter.setKey(jo.getString("key"));
                counter.setType(jo.getString("type"));

                if(jo.getInteger("value")!=null) {
                    counter.setNum(jo.getInteger("value"));
                }
                break;
            }
        }

    }
}
