package com.bjtu.redis;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Function {

    private final ArrayList<String> read;
    private final ArrayList<String> write;

    private final ArrayList<Counter> counter1;
    private final ArrayList<Counter> counter2;

    Change ch;

    public Function(AJ aj) throws IOException {

        this.ch=aj.getCh();

        read=aj.getRead();
        write=aj.getWrite();

        counter1 = new ArrayList<Counter>();
        counter2 = new ArrayList<Counter>();

        init();
    }

    public void Play(){

        for(Counter counter : counter1){

            switch (counter.type){

                case "num":

                    System.out.println(counter.key+" 的值为： "+ MyJedis.getValue(counter.key));
                    break;

                case "hash":
                    //时间格式校准

                    boolean dateflag1 = true;
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                    String date_string;
                    do {

                        dateflag1 = true;

                        System.out.print("请输入您要查询的开始时间（格式为yyyy-MM-dd HH:mm:ss）：");

                        Scanner ms1 = new Scanner(System.in);
                        date_string = ms1.nextLine();

                        //ms = ms1;

                        try {
                            Date date = format.parse(date_string);
                        } catch (ParseException e) {
                            System.out.println("请输入正确的时间格式！");
                            dateflag1 = false;
                        }
                    }while(dateflag1 == false);

                    String begin = date_string;

                    String date_string1;
                    do {

                        dateflag1 = true;

                        System.out.print("请输入您要查询的结束时间（格式为yyyy-MM-dd HH:mm:ss）：");

                        Scanner ms2 = new Scanner(System.in);
                        date_string1 = ms2.nextLine();

                        try {
                            Date date = format.parse(date_string1);
                        } catch (ParseException e) {
                            System.out.println("请输入正确的时间格式！");
                            dateflag1 = false;
                        }
                    }while(dateflag1 == false);

                    String end = date_string1;


                    try {
                        Date from = format.parse(begin);
                        Date to = format.parse(end);

                        //得到time-valueField的哈希表
                        Map<String,String> map = MyJedis.getHash(counter.key);
                        Set<String> keys = map.keySet();
                        SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                        int NUM = 0;

                        for(String key:keys){

                            Date it = format2.parse(key);

                            if(it.after(from)&&it.before(to)){

                                String value = map.get(key);
                                NUM+=Integer.parseInt(value);

                            }
                        }
                        System.out.println("在此时间内count增加了"+NUM);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    break;

                case "list":

                    List<String> log = MyJedis.getList(counter.key);
                    for(String s:log){
                        System.out.println(s);
                    }

                    break;

                default:

                    System.out.println(counter);
                    break;
            }
        }

        for(Counter counter : counter2){

            switch (counter.type){

                case "num":

                    MyJedis.setIncr(counter.key,counter.num);
                    break;

                case "hash":

                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                    MyJedis.setHash(counter.key,timestamp.toString(),
                            counter.num+"");
                    break;

                case "list":

                    String time = new Timestamp(System.currentTimeMillis()).toString();

                    int value = counter.num;
                    String write = "counter 于 "+ time + "新增了 "+ value + "个";

                    MyJedis.setList(counter.key,write);
                    break;

                default:

                    System.out.println(counter);
                    break;

            }
        }
    }

    public void init() throws IOException {

        for(String readName:read){

            Counter counter = new Counter(readName);
            new CJ(counter);
            counter1.add(counter);

        }

        for(String writeName:write){

            Counter counter = new Counter(writeName);
            new CJ(counter);
            counter2.add(counter);

        }
    }

}
